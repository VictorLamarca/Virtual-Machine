#ifndef INICIALIZACAO_H_
#define INICIALIZACAO_H_

#include "funcoes_auxiliares.h"

void preLoader();

#endif /* INICIALIZACAO_H_ */
