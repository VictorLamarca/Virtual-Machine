#ifndef MONTADOR_H_
#define MONTADOR_H_

#include "funcoes_auxiliares.h"
using namespace std;

bool montador(string arquivo);

bool poeArquivo(int val, int tam, FILE *pfile);

#endif /* MONTADOR_H_ */
