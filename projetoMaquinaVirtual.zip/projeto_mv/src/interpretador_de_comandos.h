/*
 * interpretador_de_comandos.h
 *
 *  Created on: 30 de jun de 2018
 *      Author: vlamarca
 */

#ifndef INTERPRETADOR_DE_COMANDOS_H_
#define INTERPRETADOR_DE_COMANDOS_H_

#include "funcoes_auxiliares.h"

void interpretadorDeComandos();

void imprime_arquivios_no_diretorio();


#endif /* INTERPRETADOR_DE_COMANDOS_H_ */
