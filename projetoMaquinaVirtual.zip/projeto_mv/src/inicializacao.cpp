#include "inicializacao.h"

#define prin(a) if(idebug) cout << #a << " = " << (a) << endl
#define ppal(a)  if(idebug) cout << #a << endl
#define cendl if(idebug) cout << endl
#define prinpar(p) if(idebug) cout << #p << ".fi=" << (p).fi << " " << #p << ".se=" << (p).se << endl
#define prinv(v) if(idebug){ cout << #v << ":" << endl; for(auto it = (v).begin(); it!=(v).end();it++){ cout << (int)(*it) << " ";} cout << endl;}

#define pb push_back
#define all(a) a.begin(),a.end()
#define fi first
#define se second
#define fr(i,n) for(int i=0;i<n;i++)
#define frr(i,a,b) for(int i =a;i<=b;i++)

#define BYTE unsigned char
#define DOIS_BYTES unsigned short int

void preLoader(){
	{
		FILE *pObjeto = fopen("loader.obj","r");

		int tamanho;

		string aux = "00";
		fr(i,3) fscanf(pObjeto," %c%c", &aux[0], &aux[1]);
		tamanho =  toVal('/'+aux);

		fr(i,tamanho){
			fscanf(pObjeto," %c%c", &aux[0], &aux[1]);
			memoria_principal[i] = toVal('/'+aux);
		}
	}
	{
			FILE *pObjeto = fopen("dumper.obj","r");

			int tamanho;

			string aux = "00";
			fr(i,3) fscanf(pObjeto," %c%c", &aux[0], &aux[1]);
			tamanho =  toVal('/'+aux);

			fr(i,tamanho){
				fscanf(pObjeto," %c%c", &aux[0], &aux[1]);
				memoria_principal[50+i] = toVal('/'+aux);
			}
	}

	return;
}

int main (int argc, char *argv[]){

	montador("loader");
	montador("dumper");
	preLoader();

	//chamda da interface
	interpretadorDeComandos();

	//maquina_virtual("n_quadrado");

	//Byte do n2
	//prin(byteToHexa(memoria_principal[16*16+3*16+6]));

	/*//vendo se loader funcionou
	fr(i,2*16+8){
		prin(byteToHexa(memoria_principal[16*16+16+i]));
	}*/

	//interpretadorDeComandos();
		//montador("n_quadrado");

	/*vector<string> v = {"80", "22", "90", "27", "90", "24", "90", "26", "80", "27", "50", "25", "10", "20", "80", "27", "40", "22", "90", "27", "80", "24", "40", "23", "90", "24", "40", "26", "90", "26", "00", "08", "30", "30", "01", "02", "00", "03", "00", "00"} ;
	fr(i,v.size()){
		memoria_principal[i] = (BYTE)toVal('/'+v[i]);
	}
	ci = 0;
	simuladorDeExecucao(nullptr,nullptr);

	fr(i,v.size()){
		prin(byteToHexa(memoria_principal[i]));
	}*/

	cout << "Sistema desligando" << endl;
}
